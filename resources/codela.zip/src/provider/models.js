var Model = require('../lib/model');

module.exports = {
	list: new Model('list', []),
	setting: new Model('setting', []),
	appCodeList: new Model('appCodeList', []),
	create: function(data) {
		return new Model(data);
	}
};