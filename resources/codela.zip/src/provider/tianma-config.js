var ejs = require('ejs'),
	fs = require('fs'),
	nodePath = require('path'),
	exec = require("child_process").exec,
	models = require('./models'),
	isMac = (process.platform === 'darwin');

var template = '',
	path = nodePath.join(__dirname, '../tmpl/tianma-config.tpl'),
	compile = null,
	proc = null,
	cwd = null,
	getCwd = function() {
		var setting;
		if (cwd) {
			return cwd;
		} else {
			setting = models.setting.get()[0];
			cwd = setting && setting.tianma;
		}

		return cwd;
	},
	getPid = function() {
		var cwd = getCwd(),
			path = cwd && nodePath.join(cwd, '.pid'),
			pid = '';
		if (path && fs.existsSync(path)) {
			pid = fs.readFileSync(path, 'utf8');
		}
		return pid;
	};

module.exports.create = function(project, callback) {
	var cwd = getCwd(),
		roots,
		config,
		name = '',
		configPath;
	if (!cwd) {
		throw new Error('Please select tianma working directory.');
	}

	if (!project) {
		throw new Error('Please provide a project data.');
	}

	if (!template) {
		template = fs.readFileSync(path, 'utf8');
	}
	compile = compile || ejs.compile(template, {
		filename: __dirname
	});
	roots = project.branches.map(function(item) {
		var path = nodePath.join(project.location, item.name);
		if (item.name === 'intl-style') {
			path = nodePath.join(path, '/deploy/htdocs');
		}

		return path.replace(/\\/g, '\\\\');
	});
	config = compile({
		roots: roots
	});
	name = project.name.trim().replace(/\s+/g, '_');
	name = 'config-' + name + '.js';

	configPath = nodePath.join(cwd, name);

	fs.writeFileSync(configPath, config);

	this.startws(name, callback);

	this._runningPath = configPath;
	this._runningId = project.id;
};

module.exports.getRunningPath = function() {
	return this._runningPath || '';
};

module.exports.getRunningName = function() {
	return this._runningName || '';
};

module.exports.getRunningId = function() {
	return this._runningId || '';
};

module.exports.startws = function(name, callback) {
	this.killws();
	var cwd = getCwd(),
		cmdPrefix = 'run ';

	this._runningName = name;

	if (isMac) {
		cmdPrefix = './run ';
	}
	proc = exec(cmdPrefix + name, {
		cwd: cwd,
		env: process.env
	});
	
	proc.stdout.on('data', function(data) {
		var path = nodePath.join(cwd, '.pid'),
			matcher = data.match(/\:\:(\w+)\:\:/),
			pid = matcher && matcher[1];

		if (pid) {
			fs.writeFileSync(path, pid);
		}
	});
	if (callback) {
		callback();
	}
};

module.exports.killws = function(callback) {
	var cwd = getCwd(),
		pid,
		path,
		cmdPrefix = 'taskkill /F /PID ';

	if (!cwd) {
		callback();
	}
	pid = getPid();
	path = nodePath.join(cwd, '.pid');

	if (proc) {
		proc.kill();
		proc = null;
	}

	if (pid) {

		if (isMac) {
			cmdPrefix = 'kill ';
		}
		exec(cmdPrefix + pid, function() {
			fs.unlinkSync(path);
			if (callback) {
				callback();
			}
			this._runningName = this._runningPath = this._runningId = '';
		});
	} else if (callback) {
		callback();
	}
	this._runningName = this._runningPath = this._runningId = '';
};