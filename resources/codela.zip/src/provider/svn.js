var SVN = require('node.svn'),
	nodePath = require('path'),
	models = require('./models');

module.exports = function(projectName, callback) {
	var setting = models.setting.get()[0];
	var cwd = setting && setting.workdir;
	var config = {};
	if (!cwd) {
		// throw new Error('Please select current working directory.');
		return null;
	}
	if (projectName && typeof projectName === 'string') {
		cwd = nodePath.join(cwd, projectName);
	}
	config.cwd = cwd;
	if (setting && setting.username && setting.password) {
		config.username = setting.username;
		config.password = setting.password;
	}
	return new SVN(config, function(err) {
		var errMsg = err && err.message;
		if (errMsg && errMsg.indexOf('[SVN ERROR:404]') !== -1 && callback) {
			callback(errMsg);
		}
	});
};