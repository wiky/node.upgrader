var en = {
	NAME: 'CodeLa',
	// toolbar
	exit: 'Exit',
	home: 'Home',
	setting: 'Setting',
	minimize: 'Minimize',
	exitConfirm: 'Are you exit?',
	removeConfirm: 'Are you sure to remove this project?',

	panel: 'Main Window',

	save: 'Save',
	close: 'Close',
	// list
	newProject: 'New Project',
	projectName: 'Project Name',
	branchUrl: 'Branch URL',
	branchEg: ', http://svn.alibaba-inc.com/repos/ali_intl_share/intl-style/branches/xxxxxx',
	addProject: 'Add Project',
	cancel: 'Cancel',
	openWithFolder: 'Open Containing Folder',
	openWithBrowser: 'Open In Browser',
	branchNotExist: 'Branch Not Exist',
	branchExist: 'Branch Has Exist',
	projectNotBlank: '项目名不能为空',
	projectNotSpecial: '项目名不能包含/\\?*"<>|',
	branchItemAtLeast: '至少有一个有效的分支',

	// detail
	projectList: 'Project List',
	selectAppCode: 'Select App Code',
	appCodeName: 'App Code Name',
	newAppCode: 'New App Code',
	appCodePath: 'App Code Path',
	appCodePathEx: 'App Code Path, ex. /deploy/htdocs/js/6v/biz',
	checkout: 'Checkout',
	commit: 'Commit',
	update: "Update",
	checkoutAll: '未选择“子代码路径”，将检出或更新全分支代码，速度可能会比较慢，确定继续？',

	// 设置
	settings: 'Settings',
	general: 'General',
	workDirectory: 'Work Directory',
	workdirTip: 'Please select the working directory to initialize',
	username: 'SVN Username',
	password: 'SVN Password',
	workWithTianma: 'Work with Tianma',
	tianmaLocation: 'Tianma Location',
	browse: 'Browse',
	change: 'Change',
	colon: ': '
};

var cn = {
	NAME: 'Codela',

	// toolbar
	exit: '退出',
	home: '主页',
	setting: '设置',
	minimize: '最小化',
	exitConfirm: '确定要退出吗？',
	removeConfirm: '确定删除该项目？',

	panel: '主窗口',

	save: '保存',
	close: '关闭',
	newProject: '新建项目',
	projectName: '项目名',
	branchUrl: '分支地址',
	branchEg: '， http://svn.alibaba-inc.com/repos/ali_intl_share/intl-style/branches/xxxxxx',
	addProject: '添加项目',
	cancel: '取消',
	openWithFolder: '在包含的文件夹中打开',
	openWithBrowser: '在浏览器中打开',
	branchNotExist: '无效的分支',
	branchExist: '分支已存在',
	projectNotBlank: '项目名不能为空',
	projectNotSpecial: '项目名不能包含/\\?*"<>|',
	branchItemAtLeast: '至少有一个有效的分支',

	// detail
	projectList: '项目列表',
	selectAppCode: '选择子代码路径',
	appCodeName: '子代码路径别称',
	newAppCode: '新增子代码路径',
	appCodePath: '子代码路径',
	appCodePathEx: '子代码路径，如：/deploy/htdocs/js/6v/biz',
	checkout: '检出',
	commit: '提交',
	update: "更新",
	checkoutAll: '未选择“子代码路径”，将检出或更新全分支代码，速度可能会比较慢，确定继续？',

	// 设置
	settings: '设置',
	general: '通用',
	workDirectory: '工作目录',
	workdirTip: '初始化请选择工作目录',
	username: 'SVN 用户名',
	password: 'SVN 密码',
	workWithTianma: '与Tianma协作',
	tianmaLocation: 'Tianma位置',
	browse: '浏览',
	change: '更改',
	colon: '：'
};

module.exports = {
	en: en,
	cn: cn
};