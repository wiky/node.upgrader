var view = require('../lib/view');

var footer = view('footer', {
	el: '[data-role="footer"]'
});
module.exports = footer;