var view = require('../lib/view'),
	list = require('./list'),
	detail = require('./detail'),
	setting = require('./setting');

var main = view('main', {
	el: '[data-role="main"]',
	children: [list, detail, setting]
});
module.exports = main;