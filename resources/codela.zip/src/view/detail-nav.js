var view = require('../lib/view');

var detailNav = view('detail-nav', {
	el: '[data-role="detail-nav"]',
	renderUI: function() {
		var panel = global.runData.panel || 'checkout';
		this._prev = '';
		this.tabTo(panel);
	},
	tabTo: function (panel) {
		var prev = this._prev || global.runData.panel;

		if (panel === prev) {
			return;
		}

		if (prev) {
			this.el.find('[data-role="' + prev + '"]').removeClass('active');
			this.parent().el.find('[data-role="' + prev + '-panel"]').removeClass('active in');
		}
		if (panel) {
			this.el.find('[data-role="' + panel + '"]').addClass('active');
			this.parent().el.find('[data-role="' + panel + '-panel"]').addClass('active in');
			this._prev = panel;
		}
	}
});
module.exports = detailNav;