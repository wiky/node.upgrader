var view = require('../lib/view'),
	model = require('../provider/models').appCodeList;

var appCodeList = view('app-code', {
	model: model,
	el: '[data-role="app-code-modal"]',
	events: {
		'click [data-role="remove-code-path"]': 'removeCodePath',
		'click [data-role="add-code-path"]': 'addCodePath',
		'click [data-role="save-app-code"]': '_doSaveAppCode'
	},
	renderUI: function() {
		this.nameNode = this.el.find('[data-role="code-name"]');
		this.lastItem = this.el.find('[data-role="code-path-item-last"]');
		this.appCodeModal = this.el.find('#newAppCodeModal');
	},
	bindUI: function() {
		this.model.on('add', $.proxy(this._uiSaveAppCode, this));
		setTimeout($.proxy(function() {
			this.appCodeModal.on('shown.bs.modal', $.proxy(function() {
				this.nameNode.parents('form')[0].reset();
				this.nameNode.focus();
			}, this));
			this.appCodeModal.on('hidden.bs.modal', $.proxy(function() {
				this.nameNode.parents('form')[0].reset();
			}, this));
		}, this), 0);
	},
	removeCodePath: function(e) {
		e.preventDefault();
		var target = $(e.currentTarget),
			item = target.parents('[data-role="code-path-item"]');
		item.remove();
	},
	addCodePath: function(e) {
		e.preventDefault();
		var html = this.getInclude('app-code-item'),
			lastInput = this.lastItem.find('[data-role="code-path"]'),
			input;
		html = $.parseHTML(html);
		input = $(html).find('[data-role="code-path"]');
		this.lastItem.before(html);
		input.val(lastInput.val());
		lastInput.val('').focus();
	},
	_doSaveAppCode: function(e) {
		e.preventDefault();
		var pathNodes = this.el.find('[data-role="code-path"]'),
			name = this.nameNode.val(),
			id = this.uid(),
			paths = [],
			appCode;
		pathNodes.toArray().forEach(function(path) {
			var val = $(path).val();
			if (val && paths.indexOf(val) === -1) {
				paths.push(val);
			}
		});
		if (name && paths.length > 0) {
			appCode = {
				id: id,
				name: name,
				paths: paths,
				type: this._type || ''
			};

			this.saveAppCode(appCode);
		} else if (!name) {
			// ..
		} else if (paths.length <= 0) {
			// ..
		}

	},
	switchAppCode: function(e) {
		e.preventDefault();
		var target = $(e.currentTarget),
			id = target.attr('data-id'),
			data = id && this.model.get(id);

		if (id && data) {
			this.emit('switch', id, data);
		}
	},
	saveAppCode: function(data) {
		this.model.add(data);
	},
	removeAppCode: function(e) {
		e.stopPropagation();
		var target = $(e.currentTarget),
			id = target.parents('[data-role="app-code-item"]').attr('data-id'),
			data = id && this.model.get(id);
		this.model.remove(id);
		if (id && data) {
			this.emit('remove', id, data);
		}
	},
	showModal: function(type) {
		this._type = type;
		this.appCodeModal.modal({
			backdrop: 'static'
		});
	},
	_uiSaveAppCode: function(id, data) {
		this.appCodeModal.modal('hide');
		this.emit('save', id, data);
		this.emit('switch', id, data);
	}
});
module.exports = appCodeList;