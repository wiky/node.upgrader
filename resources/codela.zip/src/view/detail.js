var view = require('../lib/view'),
	model = require('../provider/models').list,
	detailNav = require('./detail-nav'),
	checkout = require('./checkout'),
	commit = require('./commit');

var detail = view('detail', {
	el: '[data-role="detail"]',
	model: model,
	events: {
		'click [data-role="detail-nav"] li': '_tabTo'
	},
	_tabTo: function (e) {
		var el = $(e.currentTarget),
			panel = el.attr('href').replace('#', '');
		this.children[0].tabTo(panel);
	},

	children: [detailNav, checkout, commit]
});
module.exports = detail;