var view = require('../lib/view');
var children = [
	require('./header'),
	require('./footer'),
	require('./main')
];

var layout = view('layout', {
	el: window.document.body,
	events: {
		'click a[data-href]': function(e) {
			var target = $(e.currentTarget),
				href = target.attr('data-href');

			if (global.gui && href) {
				gui.Shell.openExternal(href);
			}
			return false;
		}
	},
	children: children
});

module.exports = layout;