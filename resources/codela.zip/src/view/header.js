var view = require('../lib/view');
var gui = global.gui;
var win = gui.Window.get();

var header = view('header', {
	el: '[data-role="header"]',
	events: {
		'click [data-role="minimize"]': '_doMinimize',
		'click [data-role="exit"]': '_doExit'
	},
	_doMinimize: function () {
		win.minimize();
	},
	_doExit: function () {
		var exit = window.confirm(this.$lang.exitConfirm);
		if (!exit) {
			return;
		}
		win.close(true);
	}
});
module.exports = header;