var fs = require('fs'),
	nodePath = require('path'),
	view = require('../lib/view'),
	models = require('../provider/models'),
	SVN = require('../provider/svn'),
	tianmaConfig = require('../provider/tianma-config');

var deleteFolderRecursive = function(path) {
	var files = [];
	if (fs.existsSync(path)) {
		files = fs.readdirSync(path);
		files.forEach(function(file, index) {
			var curPath = path + "/" + file;
			if (fs.statSync(curPath).isDirectory()) { // recurse
				deleteFolderRecursive(curPath);
			} else { // delete file
				fs.unlinkSync(curPath);
			}
		});
		fs.rmdirSync(path);
	}
};


var list = view('list', {
	el: '[data-role="list"]',
	events: {
		'click [data-role="new-project"]': 'showPanel',
		'click [data-role="new-project-cancel"]': 'hidePanel',
		'click [data-role="new-project-add"]': '_doAddProject',
		'click [data-role="branch-btn"].add': '_addBranchItem',
		'click [data-role="branch-btn"].remove': '_removeBranchItem',
		'click [data-role="remove-project"]': '_doRemoveProject',
		'click [data-role="view-project"]': '_doViewProject',
		'click [data-role="active-tianma"]': '_doActiveTianma',
		'click [data-role="view-branch"]': '_doViewBranch',
		'change [data-role="url"]': '_onInputChange',
		'change [data-role="name"]': '_onInputChange',
		'focusout [data-role="url"]': '_doCheckBranch',
		'focusin [data-role="url"]': '_doClearError',
		'focusout [data-role="name"]': '_doCheckName',
		'focusin [data-role="name"]': '_doClearError'
	},
	model: models.list,
	renderUI: function() {
		this.panel = this.el.find('[data-role="new-project-panel"]');
		this.nameNode = this.panel.find('[data-role="name"]');
		this.urlNode = this.panel.find('[data-role="url"]');
		this.projectList = this.el.find('[data-role="project-list"]');
		this.branches = [];
		this._checking = false;
		this.activeTianma();
	},
	bindUI: function() {
		this.model.on('add', $.proxy(this._uiAddProject, this));
		this.model.on('remove', $.proxy(this._uiRemoveProject, this));
	},
	showPanel: function(e) {
		e && e.preventDefault();
		this.resetPanel();
		this.expandPanel();
	},
	hidePanel: function(e) {
		e && e.preventDefault();
		this.panel.height(0);
	},
	resetPanel: function() {
		var html = this.getInclude('branch-item');
		this.branches = [];
		this.nameNode.parents('form')[0].reset();
		$('[data-role="branch-list"]', this.el).html(html);
	},
	expandPanel: function(animate) {
		var height;
		if (animate === false) {
			this.panel.removeClass('odin-increment-height');
		}
		height = this.panel.find('[data-role="inner"]').height();
		this.panel.height(height);
		this.nameNode.focus();
		this.panel.addClass('odin-increment-height');
	},

	_onInputChange: function(e) {
		e.preventDefault();
		var target = $(e.currentTarget);

		target.data('value-change', true);
	},

	_addBranchItem: function(e) {
		e.preventDefault();
		var html = this.getInclude('branch-item'),
			lastItem = $('[data-role="branch-item"].last', this.el),
			lastInput = $('[data-role="url"]', lastItem),
			input;
		html = $.parseHTML(html);
		input = $(html).find('[data-role="url"]');
		lastItem.removeClass('last').after(html);
		lastItem.find('.btn').removeClass('add').addClass('remove');
		lastItem.find('.btn i').removeClass('icon-plus').addClass('icon-minus');
		this.expandPanel(false);
		input.val('').focus();
	},

	_removeBranchItem: function(e) {
		e.preventDefault();
		var target = $(e.currentTarget),
			item = target.parents('[data-role="branch-item"]'),
			uid = item.find('[data-role="url"]').attr('data-uid');
		item.remove();
		this.branches = this.branches.filter(function(branch) {
			return branch && branch.id !== uid;
		});
	},

	_doCheckBranch: function(e) {
		e.preventDefault();
		var target = $(e.currentTarget),
			change = (target.data('value-change') === true);

		if (change || this._checkAways === true) {
			this._checkBranch(target);
			if (change) {
				target.data('value-change', false);
			}
		}
	},

	_doClearError: function(e) {
		e.preventDefault();
		var target = $(e.currentTarget);
		target.parent().removeClass('has-error');
		target.parent().find('.tip').hide();
	},

	_checkBranch: function(urlNode) {
		var url = urlNode.val(),
			loadingNode = $('[data-role="loading"]', urlNode.parent()),
			uid = urlNode.attr('data-uid'),
			svn = SVN();
		if (!url) {
			return;
		}
		url = url.replace(/^\s+|\s+$/g, '');
		this._checking = true;

		loadingNode.css('visibility', 'visible');

		svn.type(url, $.proxy(function(err, type) {
			loadingNode.css('visibility', 'hidden');

			var matched = url.match(/\/([^\/]+)\/(branches|trunk)/),
				name = matched && matched[1],
				has = false,
				tipNode = urlNode.parent().find('.tip'),
				tipText,
				data, html;

			if (err) {
				// Authentication failed
				if (err.toString().indexOf('E215004') !== -1) {
					// TODO tip
					//$('[data-role="alert"]').text('xxxxxxxxxxxx').fadeIn();
					window.alert(err);
				} else if (err.toString().indexOf('E155007') !== -1 || err.toString().indexOf('E200009') !== -1) { // 分支不存在	
					urlNode.parent().addClass('has-error');
					tipText = this.$lang.branchNotExist;
					tipNode.text(tipText).show();
				} else {
					window.alert(err);
				}
				this._checking = false;
				urlNode.data('error-fix', false);
				return;
			}

			this.branches.forEach(function(branch, i) {
				if (branch.name === name) {
					has = true;
				}
			});
			if (has) {
				urlNode.parent().addClass('has-error');
				tipText = this.$lang.branchExist + this.$lang.colon + name;
				tipNode.text(tipText).show();
				this._checking = false;
				urlNode.data('error-fix', false);
				return;
			}
			if (type === 'directory') {
				data = {
					id: uid || this.uid(),
					url: url,
					name: name
				};
				if (uid) {
					this.branches.every(function(branch, i) {
						if (branch.id === uid) {
							this.branches[i] = data;
							return false;
						}
						return true;
					});
				} else {
					urlNode.attr('data-uid', data.id);
					this.branches.push(data);
				}

				urlNode.tooltip('hide');
				urlNode.data('error-fix', true);
				this._checking = false;
			} else if (!type) {
				window.alert('请安装svn英文版命令行工具！');
			}

		}, this));
	},

	_doCheckName: function() {
		var name = this.nameNode.val(),
			tipNode = this.nameNode.parent().find('.tip'),
			change = (this.nameNode.data('value-change') === true);

		if (!change && this._checkAways !== true) {
			return true;
		}
		if (change) {
			this.nameNode.data('value-change', false);
		}
		if (!name) {
			this.nameNode.parent().addClass('has-error');
			tipNode.text(this.$lang.projectNotBlank).show();
			this.nameNode.data('error-fix', false);
			return false;
		}

		if (/[\/\\\?\*\"<\>\|]/.test(name)) {
			this.nameNode.parent().addClass('has-error');
			tipNode.text(this.$lang.projectNotSpecial).show();
			this.nameNode.data('error-fix', false);
			return false;
		}

		this.nameNode.data('error-fix', true);
		return true;
	},
	_readyAndAddProject: function() {
		var name = this.nameNode.val(),
			id = this.uid(),
			workdir = this._getWorkdir(),
			branchCount = this.branches.length,
			branchItems = $('[data-role="branch-list"] [data-role="branch-item"]');

		this._checkAways = true;

		if (!this._doCheckName()) {
			this._checkAways = false;
			return;
		}

		if (branchCount === 0) {
			if (!branchItems.hasClass('has-error')) {
				branchItems.addClass('has-error');
				branchItems.find('.tip').text(this.$lang.branchItemAtLeast).show();
			}
			this._checkAways = false;
			return;
		}

		branchItems = branchItems.filter(function(i, item) {
			var urlNode = $('[data-role="url"]', item);
			return !!urlNode.val();
		});

		if (branchCount < branchItems.size()) {
			$.each(branchItems, $.proxy(function(i, item) {
				var urlNode = $('[data-role="url"]', item);
				if (urlNode.data('error-fix') === false) {
					urlNode.parent().addClass('has-error');
					urlNode.parent().find('.tip').show();
				}
			}, this));
			this._checkAways = false;
			return;
		}

		var project = {
			id: id,
			name: name,
			date: new Date().getTime(),
			branches: this.branches.slice(0),
			location: workdir && nodePath.join(workdir, name),
			state: 'unpull',
			active: false
		};

		if (!fs.existsSync(project.location)) {
			fs.mkdirSync(project.location);
		}

		this.addProject(id, project);
		this._checkAways = false;
	},

	_doAddProject: function(e) {
		e.preventDefault();
		if (this._checking) {
			setTimeout($.proxy(function() {
				this._doAddProject(e);
			}, this), 200);
		} else {
			this._readyAndAddProject();
		}
	},

	_doRemoveProject: function(e) {
		e.preventDefault();
		var target = $(e.currentTarget),
			item = target.parents('[data-id]'),
			id = item.attr('data-id'),
			data, remove, runningPath,
			doRemoveFile = $.proxy(function() {
				if (fs.existsSync(runningPath)) {
					fs.unlinkSync(runningPath);
				}

				deleteFolderRecursive(data.location);
				this.removeProject(id);
			}, this);
		isRemove = window.confirm(this.$lang.removeConfirm);
		if (id && isRemove) {
			data = this.model.get(id);
			runningPath = tianmaConfig.getRunningPath();

			if (tianmaConfig.getRunningId() === id) {
				tianmaConfig.killws(function() {
					doRemoveFile();
				});
			} else {
				doRemoveFile();
			}
		}
	},
	addProject: function(id, data) {
		this.model.add(data, 'before');
	},
	removeProject: function(id) {
		this.model.remove(id);
	},
	_uiAddProject: function(id, data) {
		var html = this.getInclude('project-item', {
			project: data,
			expand: true
		});
		this.projectList.children().first().before(html);
		this.hidePanel();
		window.location.hash = '#detail/' + id;
	},
	_uiRemoveProject: function(id, data) {
		var el = this.projectList.find('[data-id="' + id + '"]');
		el.remove();
	},
	_doViewBranch: function(e) {
		e.preventDefault();
		var target = $(e.currentTarget),
			item = target.parents('[data-id]'),
			id = item.attr('data-id'),
			data = this.model.get(id),
			location = nodePath.join(data.location, target.text());

		this._openLocation(location);
	},
	_doViewProject: function(e) {
		e.preventDefault();
		var target = $(e.currentTarget),
			item = target.parents('[data-id]'),
			id = item.attr('data-id'),
			data = this.model.get(id),
			location = data.location;

		this._openLocation(location);

	},
	_openLocation: function(location) {
		var gui = global.gui;
		if (gui && gui.Shell) {
			if (!fs.existsSync(location)) {
				fs.mkdirSync(location);
			}
			gui.Shell.openItem(location);
		}
	},
	_getWorkdir: function() {
		var setting = models.setting.get()[0];
		this._workdir = this._workdir || (setting && setting.workdir);
		return this._workdir;
	},
	_doActiveTianma: function(e) {
		var target = $(e.currentTarget),
			item = target.parents('[data-id]'),
			id = item.attr('data-id');
		this.activeTianma(id);
	},
	activeTianma: function(id) {
		var list = $('[data-id]', this.projectList),
			current, data;

		if (!id) {
			this.model.get().every(function(item, i) {
				if (item.active === true) {
					id = item.id;
					return false;
				}
				return true;
			});
		}

		if (!id) {
			return;
		}

		current = $('[data-id="' + id + '"]', this.projectList);
		data = this.model.get(id);

		tianmaConfig.create(data, $.proxy(function() {
			list.each(function(i, item) {
				$(item).removeClass('odin-state-run');
			});

			current.addClass('odin-state-run');

			this.model.setAll({
				active: false
			});
			this.model.set({
				id: id,
				active: true
			});
		}, this));
	}
});
module.exports = list;