var view = require('../lib/view'),
	model = require('../provider/models').setting;

var setting = view('setting', {
	el: '[data-role="odin-setting"]',
	events: {
		'click [data-role="close"]': 'close',
		'change #inputWorkDir': '_saveWorkdir',
		'change #inputTianmaDir': '_saveTianmadir',
		'blur #inputUsername': '_saveUsername',
		'blur #inputPassword': '_savePassword',
		'click [data-role="browse-workdir"]': '_browseWorkdir',
		'click [data-role="browse-tianma"]': '_browseTianma'
	},
	model: model,
	init: function() {
		var model = this.model;
	},
	renderUI: function() {
		this.workdirBrowse = this.el.find('#inputWorkDir');
		this.tianmaBrowse = this.el.find('#inputTianmaDir');
		this.workdirText = this.el.find('[data-role="workdir-text"]');
		this.tianmaText = this.el.find('[data-role="tianma-text"]');
	},
	bindUI: function() {},
	close: function(e) {
		e.preventDefault();
		window.history.back();
	},
	onSwitchTo: function() {
		var workdirBrowseButton = $('[data-role="browse-workdir"]', this.el);
		workdirBrowseButton.tooltip({
			title: workdirBrowseButton.attr('data-title'),
			trigger: ''
		}).tooltip('hide');
		if (!this.workdirText.text()) {
			setTimeout(function() {
				workdirBrowseButton.tooltip('show');
			}, 500);
		}
	},
	_saveWorkdir: function(e) {
		e.preventDefault();
		this._addSetting();
		var val = $(e.currentTarget).val(),
			browseButton = $('[data-role="browse-workdir"]', this.el);
		if (val) {
			if (!this.workdirText.text()) {
				browseButton.text(browseButton.attr('data-label'));
				browseButton.tooltip('hide');
			}
			this.workdirText.show().text(val);

			this.model.set({
				id: 'setting',
				workdir: val
			});
		}
	},
	_saveUsername: function(e) {
		e.preventDefault();
		this._addSetting();
		var val = $(e.currentTarget).val();
		if (val) {
			this.model.set({
				id: 'setting',
				username: val
			});
		}
	},
	_savePassword: function(e) {
		e.preventDefault();
		this._addSetting();
		var val = $(e.currentTarget).val();
		if (val) {
			this.model.set({
				id: 'setting',
				password: val
			});
		}
	},
	_saveTianmadir: function(e) {
		e.preventDefault();
		this._addSetting();
		var val = $(e.currentTarget).val(),
			browseButton = $('[data-role="browse-tianma"]', this.el);
		if (val) {
			if (!this.tianmaText.text()) {
				browseButton.text(browseButton.attr('data-label'));
			}
			this.tianmaText.show().text(val);
			this.model.set({
				id: 'setting',
				tianma: val
			});
		}
	},
	_browseWorkdir: function(e) {
		e.preventDefault();
		this.workdirBrowse.trigger('click');
	},
	_browseTianma: function(e) {
		e.preventDefault();
		this.tianmaBrowse.trigger('click');
	},
	_addSetting: function() {
		if (model && model.get().length === 0) {
			model.add({
				id: 'setting'
			});
		}
	}
});

module.exports = setting;