var fs = require('fs'),
	nodePath = require('path'),
	view = require('../lib/view'),
	model = require('../provider/models').list,
	appCodeListModel = require('../provider/models').appCodeList,
	appCode = require('./app-code'),
	SVN = require('../provider/svn');

var checkout = view('checkout', {
	el: '[data-role="checkout-panel"]',
	events: {
		'click [data-role="show-modal"]': 'showModal',
		'click [data-role="app-code-item"]': 'switchAppCode',
		'click [data-role="checkout"]': 'checkout',
		'click [data-location]': '_doViewBranch',
		'click [data-role="remove-app-code"]': 'removeAppCode'
	},
	renderUI: function() {
		var id = global.runData.id;
		this.projectData = this.parent().model.get(id);
		this._svn = this._svn || {};
		this.svn = this._svn[id] = this._svn[id] || SVN(this.projectData.name);
		this.refreshPart('app-code-list', {
			appCodeList: appCodeListModel.get()
		});
	},
	bindUI: function() {
		appCode.on('save', $.proxy(function(id, data) {
			this.refreshPart('app-code-list', {
				appCodeList: appCodeListModel.get()
			});
		}, this));
		appCode.on('remove', $.proxy(function(id, data) {
			this.refreshPart('app-code-list', {
				appCodeList: appCodeListModel.get()
			});
		}, this));
		appCode.on('switch', $.proxy(function(id, data) {
			var node = this.el.find('[data-id="' + id + '"]').parents('[data-role="branch-item"]'),
				branchId = node.attr('data-id'),
				branches = this.projectData.branches;

			var current = branches.filter(function(branch) {
				return branch.id === branchId;
			})[0] || {};

			current.paths = data.paths;

			// update cache
			model.save();

			this.refreshPart('[data-id="' + branchId + '"] branch-code', {
				branch: data
			}, true);
		}, this));
	},
	checkout: function(e) {
		var target = $(e.currentTarget),
			data = this.projectData,
			svn = this.svn,
			queue = [],
			$lang = this.$lang;

		if (this._starting) {
			return;
		}

		target.lodaButton('start');
		this._starting = true;
		data.branches.forEach(function(branch) {
			var paths = branch.paths;
			if (!paths || paths.length <= 0) {
				var result = window.confirm($lang.checkoutAll);
				if (!result) {
					return;
				}
				paths = [];
			}
			queue.push(function() {
				var svn = SVN(data.name + '/' + branch.name);
				return svn.choose(branch.url, paths, function() {
					data.state = 'pull';
					model.save();
				});
			});
		});

		svn.queue(queue, function() {
			console.log('done');
		}).then($.proxy(function() {
			target.lodaButton('stop');
			var node = $('[data-update]', target);
			node.text(node.attr('data-update'));
			view().list.activeTianma(data.id);
			this._starting = false;
		}, this));
	},
	showModal: function(e) {
		var target = $(e.currentTarget),
			type = target.parents('[data-type]').attr('data-type');
		appCode.showModal(type);
	},
	switchAppCode: function(e) {
		appCode.switchAppCode(e);
	},
	removeAppCode: function(e) {
		appCode.removeAppCode(e);
	},
	children: [appCode],

	_doViewBranch: function(e) {
		var target = $(e.currentTarget),
			data = this.projectData,
			pathArr = [data.location].concat(target.attr('data-location').split('|'));
		location = nodePath.join.apply(nodePath, pathArr);
		this._openLocation(location);
	},
	_openLocation: function(location) {
		var gui = global.gui;
		if (gui && gui.Shell) {
			if (fs.existsSync(location)) {
				gui.Shell.openItem(location);
			}
		}
	}
});

module.exports = checkout;