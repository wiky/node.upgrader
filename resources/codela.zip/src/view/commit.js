var view = require('../lib/view'),
	model = require('../provider/models').list,
	SVN = require('../provider/svn');

var Commit = view('commit', {
	el: '[data-role="commit-panel"]',
	events: {
		'click [data-role="select-branch"]': '_doRefreshCommitList',
		'click [data-role="select-all"]': '_doSelectAll',
		'click [data-role="select-item"]': '_doSelectItem',
		'click [data-role="refresh"]': '_doRefreshCommitList',
		'click [data-role="commit"]': '_doCommit'
	},
	renderUI: function() {
		var id = global.runData.id;
		if (!id) {
			return;
		}
		this.projectData = this.parent().model.get(id);
		this._svn = this._svn || {};
		this.svn = this._svn[id] = this._svn[id] || SVN(this.projectData.name);
		//this.refreshCommitList();
	},
	_doRefreshCommitList: function(e) {
		this.refreshCommitList();
	},
	_doSelectItem: function(e) {
		var target = e.currentTarget,
			items = this.el.find('[data-role="select-item"]'),
			checkedItems = this.el.find('[data-role="select-item"]:checked'),
			allSelect = this.el.find('[data-role="select-all"]');

		if (!checkedItems.length || (items.length !== checkedItems.length)) {
			allSelect[0].checked = false;
		} else {
			allSelect[0].checked = true;
		}
	},
	_doSelectAll: function(e) {
		var target = e.currentTarget,
			checked = target.checked,
			items = this.el.find('[data-role="select-item"]');

		items.each(function(i, item) {
			item.checked = checked;
		});

	},
	refreshCommitList: function() {
		var selectBranches = this.el.find('[data-role="select-branch"]:checked'),
			branchesName = [],
			data = this.projectData,
			svn = this.svn,
			queue = [],
			changeList = [];

		if (data.state === 'unpull') {
			return;
		}
		selectBranches.each(function(i, branch) {
			branchesName.push($(branch).val());
		});

		if (this._refreshing) {
			return;
		}
		this._refreshing = true;
		data.branches.forEach(function(branch) {
			var paths = branch.paths,
				name = branch.name;
			if (branchesName.indexOf(name) !== -1) {
				if (paths && paths.length > 0) {
					queue.push(function() {
						return svn.status(function(err, list) {
							if (list && list.length > 0) {
								changeList.push({
									list: list,
									name: name
								});
							}
						});
					});
				}
			}
		});

		svn.queue(queue, $.proxy(function() {
			this.refreshPart('commit-list', {
				data: {
					changes: changeList
				}
			});
		}, this)).then($.proxy(function() {
			this._refreshing = false;
		}, this));
	},
	_doCommit: function(e) {
		var target = $(e.currentTarget),
			data = this.projectData,
			changeGroup = this.el.find('[data-role="change-list"] [data-type]'),
			branches = {};
		changeGroup.each(function(i, changeList) {
			var items = $(changeList).find('[data-role="select-item"]'),
				type = $(changeList).attr('data-type');

			branches[type] = [];
			items.each(function(j, item) {
				branches[type].push($(item).val());
			});
		});
	}
});

module.exports = Commit;