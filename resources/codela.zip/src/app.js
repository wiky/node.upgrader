var Control = require('./lib/control'),
	view = require('./lib/view'),
	layout = require('./view/layout'),
	models = require('./provider/models'),
	SVN = require('./provider/svn');

require('./win/gui');

var views = view();
var control = new Control({
	route: ':page/:id/:panel'
});

control.on('load', function() {
	layout.render();
});

control.on('switchTo', function(args) {
	var page = args.page,
		panel = args.data.panel || '',
		setting = models.setting.get()[0];

	if (page !== 'setting') {
		// 无指定工作目录
		if (!setting || !setting.workdir) {
			control.navigate('setting');
			return;
		} else {
			this.hide('[data-role="odin-setting"]');
			this.show('[data-role="odin-page"]');
		}
	} else {
		this.hide('[data-role="odin-page"]');
		this.show('[data-role="odin-setting"]');
		views.setting.onSwitchTo();
	}
	if (page === 'detail') {
		setTimeout(function() {
			$('[data-role="detail-nav"]').css('left', '0');
		}, 200);
		$('[data-role="odin-page"]').addClass('slided');
	} else if (page === 'default') {
		$('[data-role="odin-page"]').removeClass('slided');
		$('[data-role="detail-nav"]').css('left', '-50px');
	}
});

control.on('switchTo:default', function() {
	//views.list.refresh();
});

control.on('switchTo:detail', function(args) {
	var data = args.data;
	views.detail.refresh(data.id);
});

control.on('switchTo:settings', function() {

});


// Load native UI library
var gui = global.gui;

// Print arguments
console.log(gui.App, gui.App.manifest);

console.log('__dirname', __dirname);