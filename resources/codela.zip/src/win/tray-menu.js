var gui = global.gui,
    $ = global.$,
    listModel = require('../provider/models').list,
    lang = require('../provider/lang')['cn'],
    view = require('../lib/view');

var trayMenu = {
    get: function() {
        var menu = new gui.Menu(),
            listData = listModel.get(),
            list = view().list;

        menu.append(new gui.MenuItem({
            label: lang.panel
        }));

        menu.append(new gui.MenuItem({
            type: 'separator'
        }));

        listData.forEach(function(node) {
            var id = node.id,
                menuItem = new gui.MenuItem({
                    type: 'checkbox',
                    label: node.name,
                    click: function() {
                        menu.items.forEach(function(item){
                            if (item._isProject && item.type==='checkbox') {
                                item.checked = false;
                            }
                        });

                        this.checked = true;

                        list.activeTianma(id);
                    }
                });
            menuItem._isProject = true;
            if (node.active) {
                menuItem.checked = true;
            }
            menu.append(menuItem);
        });

        menu.append(new gui.MenuItem({
            type: 'separator'
        }));

        menu.append(new gui.MenuItem({
            label: lang.exit,
            click: function() {
                $('[data-role="header"] [data-role="exit"]').click();
            }
        }));

        return menu;
    }
};

module.exports = trayMenu;