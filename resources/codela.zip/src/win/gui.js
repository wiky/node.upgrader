var gui = global.gui,
    win = gui.Window.get(),
    tianmaCfg = require('../provider/tianma-config'),
    trayMenu = require('./tray-menu');

if (!win) {
    //window.location.reload();
    return;
}

//show dev tools with ctrl+alt+j
$(window.document).keydown(function(e) {
    if (e.altKey && e.ctrlKey && (e.which === 10 || e.keyCode === 74)) {
        win.showDevTools();
    }
});
//win.setAlwaysOnTop(true);
win.on('minimize', function() {
    win.hide();

    var tray = new gui.Tray({
        icon: 'assets/img/logo_16x16.png'
    });

    function openWin() {
        win.show();
        tray.remove();
        tray = null;
    }

    console.log(tray);
    tray.menu = trayMenu.get();

    tray.menu.items[0].click = function() {
        openWin();
    };
    
    tray.on('click', function() {
        openWin();
    });
});

win.on('close', function() {
    tianmaCfg.killws(function() {
        win.close(true);
    });
});

win.setMinimumSize(800, 600);